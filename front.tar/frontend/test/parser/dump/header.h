#define DEFINE_INT(name, initializer) int name = initializer;
